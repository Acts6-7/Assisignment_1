# Numerical Methods Project
This project implements various numerical methods in Python, demonstrating algorithms such as the Bisection Method, Fixed-Point Iteration, and Newton's Method. It is designed to run on Windows and is particularly useful for educational purposes to help understand the implementation and behavior of these algorithms. 

Before running this project, ensure you have the following: Python 3.8 or higher installed on your Windows machine. You can download it from [Python's official site](https://www.python.org/downloads/).

To get started with this project, clone or download the repository to your local machine and navigate to the project directory:
To run the numerical methods implementations, navigate to the src\main directory and execute:
This will run the main script containing the implementations of the numerical methods. Adjustments in the script may be necessary depending on the specific requirements or inputs for each method.

To verify the correctness of the implementations, navigate to the src\test directory and run:
This command runs the unit tests defined in test_assignment_1.py, ensuring that each method functions as expected.

Contributions to this project are welcome! To contribute, please fork the repository, make your changes, and submit a pull request. You can also open issues for bugs you've noticed or features you'd like to see.

For questions or feedback regarding this project, please contact [your-email@example.com](mailto:your-email@example.com).

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.






