import sys
import os
import unittest

# Adjust the path to include the 'src' directory correctly.
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
sys.path.insert(0, project_root)

# Print the current Python path to help diagnose path issues.
print("Current Python path:", sys.path)

# Try to import the modules again.
try:
    from src.main.assignment_1 import bisection_method, fixed_point_iteration, newtons_method
except ImportError as e:
    print("Failed to import modules:", e)
    sys.exit(1)

class TestNumericalAlgorithms(unittest.TestCase):

    def test_bisection_method(self):
        def func(x):
            return x**2 - 2  # Example function where root is known
        result = bisection_method(func, 1, 2, 1e-7, 100)
        self.assertAlmostEqual(result, 2 ** 0.5, places=6)

    def test_fixed_point_iteration(self):
        def g(x):
            return (2 / x + x) / 2  # Convergence to sqrt(2)
        result, _ = fixed_point_iteration(g, 1.5, 1e-6, 100)
        self.assertAlmostEqual(result, 2 ** 0.5, places=6)

    def test_newtons_method(self):
        def f(x):
            return x**2 - 2
        def df(x):
            return 2 * x
        result = newtons_method(f, df, 1.5, 1e-6, 100)
        self.assertAlmostEqual(result, 2 ** 0.5, places=6)

if __name__ == '__main__':
    unittest.main()
