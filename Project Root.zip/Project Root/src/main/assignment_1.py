def bisection_method(f, a, b, tol, max_iter):
    if f(a) * f(b) >= 0:
        print("No root found.")
        return None
    i = 0
    while i < max_iter:
        p = (a + b) / 2
        if f(a) * f(p) < 0:
            b = p
        else:
            a = p
        i += 1
        if abs(b - a) < tol:
            return p
    return "The method did not converge."

def fixed_point_iteration(g, p0, tol, max_iter):
    for i in range(max_iter):
        p = g(p0)
        if abs(p - p0) < tol:
            return p, "SUCCESS"
        p0 = p
    return p0, "FAILURE"

def newtons_method(f, df, p0, tol, max_iter):
    for i in range(max_iter):
        if df(p0) == 0:
            return "Derivative zero. No solution found."
        p_next = p0 - f(p0) / df(p0)
        if abs(p_next - p0) < tol:
            return p_next
        p0 = p_next
    return "The method did not converge."

if __name__ == "__main__":
    def func(x):
        return x**2 - 2
    def df(x):
        return 2 * x
    root = bisection_method(func, 1, 2, 1e-6, 100)
    print(f"Root using Bisection Method: {root}")
    result, status = fixed_point_iteration(lambda x: 2/x, 1.5, 1e-6, 100)
    print(f"Result using Fixed-Point Iteration: {result}, Status: {status}")
    approx_root = newtons_method(func, df, 1.5, 1e-6, 100)
    print(f"Root using Newton's Method: {approx_root}")
